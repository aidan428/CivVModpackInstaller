
Faster Aircraft
for Civilization 5 & Gods and Kings
v.3

	-- Description --

Faster aircraft animations (x2)


	-- version history --
	
v.3 (Jan 12, 2012)
- Set "reload unit system" property to true

v.2 (Aug 15, 2012)
- Fix turn rate
- Compatibility with R.E.D. WWII (v.29)