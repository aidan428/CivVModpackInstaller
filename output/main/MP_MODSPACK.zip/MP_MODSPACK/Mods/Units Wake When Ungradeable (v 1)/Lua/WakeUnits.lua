-- WakeUnits
-- Author: calcul8or
-- DateCreated: 4/6/2016 7:18:53 PM
--------------------------------------------------------------

--------------------------------------------------------------
--===================USER SETTINGS==========================--
--You can choose to have units wake, a notification, or both--
--			Both are set "on" by default					--
--	Change the 1 to a 0 to turn off either feature below:	--
local NotificationOn = 1									--
local WakeUnitOn     = 1									--
--===================USER SETTINGS==========================--
--------------------------------------------------------------

local SleepActivity		= ActivityTypes.ACTIVITY_SLEEP
local SentryActivity	= ActivityTypes.ACTIVITY_SENTRY
local NoActivity		= ActivityTypes.NO_ACTIVITY

function UnitAwake(playerID)
	local pPlayer = Players[playerID]
	if (pPlayer:IsHuman()) then
		for unit in pPlayer:Units() do
			--print("Checking units");
			if (unit:CanUpgradeRightNow()) then
				--print("Upgrade available");
				local unitActivity = unit:GetActivityType()
				if (unitActivity == SleepActivity or unitActivity == SentryActivity) then
					if (WakeUnitOn == 1) then
						print("Waking unit");
						unit:PushMission(GameInfoTypes["MISSION_IDLE"])
					end
					if (NotificationOn == 1) then
						JFD_SendNotification(playerID, "NOTIFICATION_GENERIC", Locale.ConvertTextKey("TXT_KEY_CALC_UNIT_WAKE"), Locale.ConvertTextKey("TXT_KEY_CALC_UNIT_WAKE"), false, unit:GetX(), unit:GetY())
						print("Mission idle set");
					end
				end
			end
		end
	end
end

GameEvents.PlayerDoTurn.Add(UnitAwake)

------------------------------------------------------------------------------------------------------------------------
-- JFD_SendNotification
------------------------------------------------------------------------------------------------------------------------
function JFD_SendNotification(playerID, notificationType, description, descriptionShort, global, iX, iY)
	local player = Players[playerID]
	if global then
			Players[Game.GetActivePlayer()]:AddNotification(NotificationTypes[notificationType], description, descriptionShort, iX or -1, iY or -1)
	else
		if player:IsHuman() then
			Players[Game.GetActivePlayer()]:AddNotification(NotificationTypes[notificationType], description, descriptionShort, iX or -1, iY or -1)
		end
	end
end
		