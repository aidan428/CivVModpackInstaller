INSERT INTO CustomModDbUpdates(Name, Value) VALUES('UI_CITY_EXPANSION', 1);
