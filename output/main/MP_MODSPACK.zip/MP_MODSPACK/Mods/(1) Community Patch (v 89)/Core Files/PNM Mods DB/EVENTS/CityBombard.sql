-- Maximum city bombard range
INSERT INTO Defines(Name, Value) VALUES('MAX_CITY_ATTACK_RANGE', 2);

INSERT INTO CustomModDbUpdates(Name, Value) VALUES('EVENTS_CITY_BOMBARD', 1);
